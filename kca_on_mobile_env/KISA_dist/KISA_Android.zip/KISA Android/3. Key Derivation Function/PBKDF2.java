package kr.or.kisa.seed.pbkdf2;


public class PBKDF2 {
    static {
        System.loadLibrary("pbkdf2");
    }
    public native int pbkdf2(byte[] password, int passwordLen, byte[] salt, int saltLen, int iter, byte[] key, int keyLen);

    public int MD(byte[] password, int passwordLen, byte[] salt, int saltLen, int iter, byte[] key, int keyLen) {
        int retcode  = 0;

        retcode = this.pbkdf2(password, passwordLen, salt, saltLen, iter, key, keyLen);

        return retcode;
    }
}
