package kr.or.kisa.seed.eckcdsa;

public class IRR {
    int[] term;
    int top;
    int fbits;
    int basis;

    IRR(){
        term = new int[501];
    }
}
