package kr.or.kisa.seed.eckcdsa;

public class MPZ {
    int sig;
    int[] dat;
    int len;

    MPZ(){
        dat = new int[501];
    }
}
