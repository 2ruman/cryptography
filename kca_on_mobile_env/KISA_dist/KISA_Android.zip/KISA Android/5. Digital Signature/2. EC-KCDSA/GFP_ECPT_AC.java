package kr.or.kisa.seed.eckcdsa;

public class GFP_ECPT_AC {
    byte is_O;
    MPZ x;
    MPZ y;

    GFP_ECPT_AC(){
        x = new MPZ();
        y = new MPZ();
    }
}
