package kr.or.kisa.seed.eckcdsa;
import android.util.Log;

public class ECKCDSA {
    public static final int ECC_PRIME_FIELD = 0;
    public static final int ECC_CHAR2_FIELD = 1;

    public static final int SECT233k = 0;
    public static final int SECT233r = 1;
    public static final int SECT283k = 2;
    public static final int SECT283r = 3;
    public static final int SECP224r = 4;
    public static final int SECP256r = 5;

    public static final int SHA224 = 1;
    public static final int SHA256 = 2;

    static {
        System.loadLibrary("eckcdsa");
    }
    private native int eccInitParamsP(int ftype, int[] a_dat, int[] b_dat, int[] p_dat, int[] x_dat, int[] y_dat, int[] order_dat, int[] cofactor_dat, int ECC_ID);
    private native int eccInitParams2n(int ftype, int[] a2, int[] a6, int[] irr_term, int[] x, int[] y, int[] order_dat, int[] cofactor_dat, int ECC_ID);
    private native int eccSetParamsP(int ECC_ID, int ftype, int[] param);
    private native int eccSetParams2n(int ECC_ID, int ftype, int[] param);
    private native void privateKeyGenerator(int[] sk, int[] sk_param, int order_len, int order_sig, int[] order_dat, int ECC_ID, int hash, byte[] urand_val, int urand_len);
    private native void publicKeyGeneratorP(int[] p_x_dat, int[] p_y_dat, int[] point_param, int[] Private_key, int[] curve_param, int[] x_dat, int[] y_dat,
                                           int[] prime_dat, int[] a_dat, int[] b_dat, int[] order_dat);
    private native void publicKeyGenerator2n(int[] p_x, int[] p_y, int[] point_param, int[] Private_key, int[] curve_param, int[] x, int[] y,
                                            int[] a2, int[] a6, int[] irr_term, int[] order_dat);
    private native void ECKCDSAsignP(int[] p_x_dat, int[] p_y_dat, int[] x_dat, int[] y_dat, int[] prime_dat, int[] a_dat, int[] b_dat, int[] order_dat, int[] cuvre_param,
                                    int[] sk_dat, int ECC_ID, int hash, byte[] Message, int MSG_Len, byte[] signature);
    private native void ECKCDSAsign2n(int[] p_x, int[] p_y, int[] x, int[] y, int[] a2, int[] a6, int[] irr_term, int[] order_dat, int[] cuvre_param,
                                     int[] sk_dat, int ECC_ID, int hash, byte[] Message, int MSG_Len, byte[] signature);
    private native int ECKCDSAverifyP(int[] p_x_dat, int[] p_y_dat, byte[] signature, int[] x_dat, int[] y_dat, int[] prime_dat, int[] a_dat, int[] b_dat, int[] order_dat,
                                     int[] cuvre_param, int ECC_ID, int hash, byte[] Message, int MSG_Len);
    private native int ECKCDSAverify2n(int[] p_x, int[] p_y, byte[] signature, int[] x, int[] y, int[] a2, int[] a6, int[] irr_term, int[] order_dat,
                                      int[] cuvre_param, int ECC_ID, int hash, byte[] Message, int MSG_Len);

    public int ECC_init_params(int field_type, ECC_PARAMS ecc_params, int ECC_ID){
        if(field_type == ECC_PRIME_FIELD) {
            if (eccInitParamsP(field_type, ecc_params.pfield.curve.a.dat, ecc_params.pfield.curve.b.dat, ecc_params.pfield.curve.prime.dat,
                    ecc_params.pfield.base.x.dat, ecc_params.pfield.base.y.dat, ecc_params.order.dat, ecc_params.cofactor.dat, ECC_ID) != 0)
                return -1;
            ecc_params.field_type = field_type;
            ecc_params.pfield.base.is_O = 0;
        }
        else if(field_type == ECC_CHAR2_FIELD){
            if (eccInitParams2n(field_type, ecc_params.c2field.curve.a2, ecc_params.c2field.curve.a6, ecc_params.c2field.curve.irr.term,
                    ecc_params.c2field.base.x, ecc_params.c2field.base.y, ecc_params.order.dat, ecc_params.cofactor.dat, ECC_ID) != 0)
                return -1;
            ecc_params.field_type = field_type;
            ecc_params.c2field.base.is_O = 0;
        }
        else
            return -1;

        return 0;
    }

    public int ECC_set_params(int ECC_ID, ECC_PARAMS ecc_params){
        if(ecc_params.field_type == ECC_PRIME_FIELD) {
            int[] param = new int[15];
            if (eccSetParamsP(ECC_ID, ecc_params.field_type, param) != 0)
                return -1;

            ecc_params.pfield.curve.a.len = param[0];
            ecc_params.pfield.curve.a.sig = param[1];
            ecc_params.pfield.curve.b.len = param[2];
            ecc_params.pfield.curve.b.sig = param[3];
            ecc_params.pfield.curve.prime.len = param[4];
            ecc_params.pfield.curve.prime.sig = param[5];
            ecc_params.pfield.base.is_O = (byte) param[6];
            ecc_params.pfield.base.x.len = param[7];
            ecc_params.pfield.base.x.sig = param[8];
            ecc_params.pfield.base.y.len = param[9];
            ecc_params.pfield.base.y.sig = param[10];
            ecc_params.order.len = param[11];
            ecc_params.order.sig = param[12];
            ecc_params.cofactor.len = param[13];
            ecc_params.cofactor.sig = param[14];
        }
        else if(ecc_params.field_type == ECC_CHAR2_FIELD){
            int[] param = new int[7];
            if (eccSetParams2n(ECC_ID, ecc_params.field_type, param) != 0)
                return -1;

            ecc_params.c2field.curve.irr.top = param[0];
            ecc_params.c2field.curve.irr.fbits = param[1];
            ecc_params.c2field.base.is_O = (byte)param[2];
            ecc_params.order.len = param[3];
            ecc_params.order.sig = param[4];
            ecc_params.cofactor.len = param[5];
            ecc_params.cofactor.sig = param[6];
        }
        else
            return -1;

        return 0;
    }

    public void Private_Key_generator(MPZ sk, ECC_PARAMS curve, int ECC_ID, int hash, byte[] urand_val, int urand_len){
        int[] sk_param = new int[2];
        privateKeyGenerator(sk.dat, sk_param, curve.order.len, curve.order.sig, curve.order.dat, ECC_ID, hash, urand_val, urand_len);

        sk.len = sk_param[0];
        sk.sig = sk_param[1];
    }

    public void Public_Key_generator(ECC_POINT Public_point, int[] Private_key, ECC_PARAMS curve){
        if(curve.field_type == ECC_PRIME_FIELD) {
            int[] curve_param = new int[13];
            int[] point_param = new int[5];
            curve_param[0] = curve.pfield.base.is_O;
            curve_param[1] = curve.pfield.base.x.len;
            curve_param[2] = curve.pfield.base.x.sig;
            curve_param[3] = curve.pfield.base.y.len;
            curve_param[4] = curve.pfield.base.y.sig;
            curve_param[5] = curve.pfield.curve.prime.len;
            curve_param[6] = curve.pfield.curve.prime.sig;
            curve_param[7] = curve.pfield.curve.a.len;
            curve_param[8] = curve.pfield.curve.a.sig;
            curve_param[9] = curve.pfield.curve.b.len;
            curve_param[10] = curve.pfield.curve.b.sig;
            curve_param[11] = curve.order.len;
            curve_param[12] = curve.order.sig;

            publicKeyGeneratorP(Public_point.pfield_point.x.dat, Public_point.pfield_point.y.dat, point_param, Private_key, curve_param, curve.pfield.base.x.dat, curve.pfield.base.y.dat,
                    curve.pfield.curve.prime.dat, curve.pfield.curve.a.dat, curve.pfield.curve.b.dat, curve.order.dat);

            Public_point.pfield_point.is_O = (byte) point_param[0];
            Public_point.pfield_point.x.len = point_param[1];
            Public_point.pfield_point.x.sig = point_param[2];
            Public_point.pfield_point.y.len = point_param[3];
            Public_point.pfield_point.y.sig = point_param[4];
        }
        else if(curve.field_type == ECC_CHAR2_FIELD){
            int[] curve_param = new int[6];
            int[] point_param = new int[1];
            curve_param[0] = curve.c2field.base.is_O;
            curve_param[1] = curve.c2field.curve.irr.top;
            curve_param[2] = curve.c2field.curve.irr.fbits;
            curve_param[3] = curve.c2field.curve.irr.basis;
            curve_param[4] = curve.order.len;
            curve_param[5] = curve.order.sig;

            publicKeyGenerator2n(Public_point.c2field_point.x, Public_point.c2field_point.y, point_param, Private_key, curve_param, curve.c2field.base.x, curve.c2field.base.y,
                    curve.c2field.curve.a2, curve.c2field.curve.a6, curve.c2field.curve.irr.term, curve.order.dat);

            Public_point.c2field_point.is_O = (byte)point_param[0];
        }
        else
            return;
    }

    public void EC_KCDSA_sign(ECC_POINT Public_point, ECC_PARAMS curve, int[] Private_key, int ECC_ID, int hash, byte[] Message, int MSG_len, byte[] signature){
        if(curve.field_type == ECC_PRIME_FIELD) {
            int[] curve_param = new int[13];
            curve_param[0] = curve.pfield.base.is_O;
            curve_param[1] = curve.pfield.base.x.len;
            curve_param[2] = curve.pfield.base.x.sig;
            curve_param[3] = curve.pfield.base.y.len;
            curve_param[4] = curve.pfield.base.y.sig;
            curve_param[5] = curve.pfield.curve.prime.len;
            curve_param[6] = curve.pfield.curve.prime.sig;
            curve_param[7] = curve.pfield.curve.a.len;
            curve_param[8] = curve.pfield.curve.a.sig;
            curve_param[9] = curve.pfield.curve.b.len;
            curve_param[10] = curve.pfield.curve.b.sig;
            curve_param[11] = curve.order.len;
            curve_param[12] = curve.order.sig;

            ECKCDSAsignP(Public_point.pfield_point.x.dat, Public_point.pfield_point.y.dat, curve.pfield.base.x.dat, curve.pfield.base.y.dat, curve.pfield.curve.prime.dat,
                    curve.pfield.curve.a.dat, curve.pfield.curve.b.dat, curve.order.dat, curve_param, Private_key, ECC_ID, hash, Message, MSG_len, signature);
        }
        else if(curve.field_type == ECC_CHAR2_FIELD){
            int[] curve_param = new int[6];
            curve_param[0] = curve.c2field.base.is_O;
            curve_param[1] = curve.c2field.curve.irr.top;
            curve_param[2] = curve.c2field.curve.irr.fbits;
            curve_param[3] = curve.c2field.curve.irr.basis;
            curve_param[4] = curve.order.len;
            curve_param[5] = curve.order.sig;

            ECKCDSAsign2n(Public_point.c2field_point.x, Public_point.c2field_point.y, curve.c2field.base.x, curve.c2field.base.y, curve.c2field.curve.a2, curve.c2field.curve.a6,
                    curve.c2field.curve.irr.term, curve.order.dat, curve_param, Private_key, ECC_ID, hash, Message, MSG_len, signature);
        }
        else
            return;
    }

    public int EC_KCDSA_verify(ECC_POINT Public_point, byte[] signature, ECC_PARAMS curve, int ECC_ID, int hash, byte[] Message, int MSG_Len){
        if(curve.field_type == ECC_PRIME_FIELD) {
            int[] curve_param = new int[13];
            curve_param[0] = curve.pfield.base.is_O;
            curve_param[1] = curve.pfield.base.x.len;
            curve_param[2] = curve.pfield.base.x.sig;
            curve_param[3] = curve.pfield.base.y.len;
            curve_param[4] = curve.pfield.base.y.sig;
            curve_param[5] = curve.pfield.curve.prime.len;
            curve_param[6] = curve.pfield.curve.prime.sig;
            curve_param[7] = curve.pfield.curve.a.len;
            curve_param[8] = curve.pfield.curve.a.sig;
            curve_param[9] = curve.pfield.curve.b.len;
            curve_param[10] = curve.pfield.curve.b.sig;
            curve_param[11] = curve.order.len;
            curve_param[12] = curve.order.sig;

            if (ECKCDSAverifyP(Public_point.pfield_point.x.dat, Public_point.pfield_point.y.dat, signature, curve.pfield.base.x.dat, curve.pfield.base.y.dat, curve.pfield.curve.prime.dat,
                    curve.pfield.curve.a.dat, curve.pfield.curve.b.dat, curve.order.dat, curve_param, ECC_ID, hash, Message, MSG_Len) != 0)
                return -1;
        }
        else if(curve.field_type == ECC_CHAR2_FIELD){
            int[] curve_param = new int[6];
            curve_param[0] = curve.c2field.base.is_O;
            curve_param[1] = curve.c2field.curve.irr.top;
            curve_param[2] = curve.c2field.curve.irr.fbits;
            curve_param[3] = curve.c2field.curve.irr.basis;
            curve_param[4] = curve.order.len;
            curve_param[5] = curve.order.sig;

            if (ECKCDSAverify2n(Public_point.c2field_point.x, Public_point.c2field_point.y, signature, curve.c2field.base.x, curve.c2field.base.y, curve.c2field.curve.a2, curve.c2field.curve.a6,
                    curve.c2field.curve.irr.term, curve.order.dat, curve_param, ECC_ID, hash, Message, MSG_Len) != 0)
                return -1;
        }
        else
            return -1;

        return 0;
    }
	
	public void Public_Key_set_params(ECC_POINT Public_point, ECC_PARAMS curve, int[] x_Q, int x_Q_len, int[] y_Q, int y_Q_len)	{
		if(curve.field_type == ECC_PRIME_FIELD) {
			Public_point.pfield_point.x.len = curve.pfield.base.x.len;
			Public_point.pfield_point.y.len = curve.pfield.base.y.len;

			Public_point.pfield_point.is_O = 0;
			Public_point.pfield_point.x.sig = 1;
			Public_point.pfield_point.y.sig = 1;

			for (int i = 0; i < x_Q_len; ++i) Public_point.pfield_point.x.dat[i] = x_Q[i];
			for (int i = 0; i < y_Q_len; ++i) Public_point.pfield_point.y.dat[i] = y_Q[i];
		}
		else if(curve.field_type == ECC_CHAR2_FIELD) {
			Public_point.c2field_point.is_O = 0;
		
			for (int i = 0; i < x_Q_len; ++i) Public_point.c2field_point.x[i] = x_Q[i];
			for (int i = 0; i < y_Q_len; ++i) Public_point.c2field_point.y[i] = y_Q[i];
		}
		else
			return;
	}
}
