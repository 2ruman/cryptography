package kr.or.kisa.seed.eckcdsa;

public class ECC_PARAMS {
    int field_type;
    ECCP_PFIELD pfield;
    ECCP_2NFIELD c2field;
    MPZ order;
    MPZ cofactor;

    ECC_PARAMS(){
        pfield = new ECCP_PFIELD();
        c2field = new ECCP_2NFIELD();
        order = new MPZ();
        cofactor= new MPZ();
    }
}
