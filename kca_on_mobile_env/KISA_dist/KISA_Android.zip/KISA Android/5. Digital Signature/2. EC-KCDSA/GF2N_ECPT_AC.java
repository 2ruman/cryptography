package kr.or.kisa.seed.eckcdsa;

public class GF2N_ECPT_AC {
    byte is_O;
    int[] x;
    int[] y;

    GF2N_ECPT_AC(){
        x = new int[501];
        y = new int[501];
    }
}
