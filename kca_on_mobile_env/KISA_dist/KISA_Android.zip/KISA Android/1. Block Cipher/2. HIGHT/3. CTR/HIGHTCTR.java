package kr.or.kisa.seed.hight;

public class HIGHTCTR {
    public static final int HIGHT_BLOCK_SIZE = 8;

    public static final int ENC = 1;
    public static final int DEC = 0;

    private int 	encrypt;
    private byte[]	mkey;
    private byte[] 	ivec;
    private byte[]	hightKey;
    private int[] 	buffer_length;
    private int[] 	last_block_flag;

    public HIGHTCTR() {
	this.mkey = new byte[16];
        this.ivec = new byte[HIGHT_BLOCK_SIZE];
        this.hightKey = new byte[128];
        this.buffer_length = new int[1];
        this.last_block_flag = new int[1];
    }
    static {
        System.loadLibrary("hight");
    }

    private native int hightCTRInit(byte[] user_key, byte[] hight_key);
    private native int hightCTRProcess(byte[] hight_key, byte[] user_key, byte[] ctr, byte[] intput, int inputLen, byte[] output, int[] buffer_length);
    private native int hightCTRClose(byte[] output, int outlen1, int[] buffer_length);
    private native int CTREncrypt(byte[] key, byte[] ctr, byte[] input, int inputlen, byte[] output);
    private native int CTRDecrypt(byte[] key, byte[] ctr, byte[] input, int inputlen, byte[] output);

    public int init(int enc, byte[] key, byte[] ctr){
        if(key == null || ctr == null)
            return -1;
        if(hightCTRInit(key, this.hightKey) == -1)
            return -1;

	System.arraycopy(key, 0, this.mkey, 0, 16);
        System.arraycopy(ctr, 0, this.ivec, 0, HIGHT_BLOCK_SIZE);
        this.encrypt = enc;
        this.last_block_flag[0] = this.buffer_length[0] = 0;

        return 0;
    }

    public int process(byte[] input, int inputLen, byte[] output){
        int outputTextLen = 0;

        if(input == null || output == null)
            return -1;

        if(inputLen <= 0)
            return -1;

        outputTextLen = hightCTRProcess(this.hightKey, this.mkey, this.ivec, input, inputLen, output, this.buffer_length);
        return outputTextLen;
    }

    public int close(byte[] output, int outlen1){
        int outputLen = 0;
        if(output == null)
            return -1;

        outputLen = hightCTRClose(output, outlen1, this.buffer_length);

        return outputLen;
    }

    public int CTR_Encrypt(byte[] key, byte[] counter, byte[] input, int inputLen, byte[] output){
        int len;
        if(key == null || counter == null || input == null || output == null)
            return -1;

        len = CTREncrypt(key, counter, input, inputLen, output);

        if(len == 0)
            return -1;

        return len;
    }

    public int CTR_Decrypt(byte[] key, byte[] counter, byte[] input, int inputLen, byte[] output){
        int len;
        if(key == null || counter == null || input == null || output == null)
            return -1;

        len = CTRDecrypt(key, counter, input, inputLen, output);

        if(len == 0)
            return -1;

        return len;
    }
}
