package kr.or.kisa.seed.hight;

public class HIGHTECB {
    private byte[]	hightKey;
    public HIGHTECB() {
        this.hightKey = new byte[136];
    }
    static {
        System.loadLibrary("hight");
    }

    private native int keyschedule(byte[] key, byte[] hightKey);
    private native int EncryptECB(byte[] hightKey, byte[] Data);
    private native int DecryptECB(byte[] hightKey, byte[] Data);

    public int key_schedule(byte[] key){
        if(key == null)
            return -1;
        if(keyschedule(key, this.hightKey) == -1)
            return -1;

        return 0;
    }

    public int Encrypt_ECB(byte[] pbData){
        if(pbData == null)
            return -1;
        if(EncryptECB(this.hightKey, pbData) == -1)
            return -1;

        return 0;
    }

    public int Decrypt_ECB(byte[] pbData){
        if(pbData == null)
            return -1;
        if(DecryptECB(this.hightKey, pbData) == -1)
            return -1;

        return 0;
    }
}
