package kr.or.kisa.seed;

public class SEEDECB {
    private int[]	seedKey;

    public SEEDECB() {
        this.seedKey = new int[32];
    }
    static {
        System.loadLibrary("seed");
    }

    private native int keyschedule(byte[] key, int[] seedKey);
    private native int ECBEncrypt(byte[] pbData, int[] seedKey);
    private native int ECBDecrypt(byte[] pbData, int[] seedKey);

    public int key_schedule(byte[] key){
        if(key == null)
            return -1;
        if(keyschedule(key, this.seedKey) == -1)
            return -1;

        return 0;
    }

    public int ECB_ENCRYPT(byte[] inoutText){
        if(inoutText == null)
            return -1;
        if(ECBEncrypt(inoutText, this.seedKey) == -1)
            return -1;

        return 0;
    }

    public int ECB_DECRYPT(byte[] inoutText){
        if(inoutText == null)
            return -1;
        if(ECBDecrypt(inoutText, this.seedKey) == -1)
            return -1;

        return 0;
    }
}
