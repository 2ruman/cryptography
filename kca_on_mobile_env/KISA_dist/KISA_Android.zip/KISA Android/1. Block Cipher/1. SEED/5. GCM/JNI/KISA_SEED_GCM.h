#ifndef _SEED_GCM_H_
#define _SEED_GCM_H_


// include header
#include <jni.h>

// define


// function declare
#ifdef __cplusplus
extern "C" 
{
#endif
int SEED_GCM_Encryption(
    unsigned char *ct, unsigned int *ctLen,
    unsigned char *pt, unsigned int ptLen,
    unsigned int macLen,
    unsigned char *nonce, unsigned int noncelen,
    unsigned char *aad, unsigned int aadlen,
    unsigned char *mKey);
int SEED_GCM_Decryption(
    unsigned char *pt, unsigned int *ptLen,
    unsigned char *ct, unsigned int ctLen,
    unsigned int macLen,
    unsigned char *nonce, unsigned int nonceLen,
    unsigned char *aad, unsigned int aadLen,
    unsigned char *mKey);

JNIEXPORT jint JNICALL
Java_kr_or_kisa_seed_SEEDGCM_GCMEncryption(JNIEnv* env, jobject thiz, jbyteArray Ct, jbyteArray Pt, jint PtLen, jint MacLen, jbyteArray Nonce, jint NonceLen, jbyteArray Aad, jint AadLen, jbyteArray Key);
JNIEXPORT jint JNICALL
Java_kr_or_kisa_seed_SEEDGCM_GCMDecryption(JNIEnv* env, jobject thiz, jbyteArray Pt, jbyteArray Ct, jint CtLen, jint MacLen, jbyteArray Nonce, jint NonceLen, jbyteArray Aad, jint AadLen, jbyteArray Key);

#ifdef __cplusplus
}
#endif



#else
#endif
