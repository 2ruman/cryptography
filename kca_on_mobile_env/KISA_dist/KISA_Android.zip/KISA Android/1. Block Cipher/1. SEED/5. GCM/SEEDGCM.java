package kr.or.kisa.seed;

public class SEEDGCM {
    static {
        System.loadLibrary("seed");
    }

    private native int GCMEncryption(byte[] ct, byte[] pt, int ptLen, int macLen, byte[] nonce, int nonceLen, byte[] aad, int aadLen, byte[] key);
    private native int GCMDecryption(byte[] pt, byte[] ct, int ctLen, int macLen, byte[] nonce, int nonceLen, byte[] aad, int aadLen, byte[] key);

    public int GCM_Encryption(byte[] ct, byte[] pt, int ptLen, int macLen, byte[] nonce, int nonceLen, byte[] aad, int aadLen, byte[] mKey) {
        int ctLen;
        if(mKey == null)
            return -1;

        ctLen = GCMEncryption(ct, pt, ptLen, macLen, nonce, nonceLen, aad, aadLen, mKey);
        if(ctLen == -1)
            return -1;

        return ctLen;
    }

    public int GCM_Decryption(byte[] pt, byte[] ct, int ctLen, int macLen, byte[] nonce, int nonceLen, byte[] aad, int aadLen, byte[] mKey){
        int ptLen = 0;
        if(mKey == null)
            return -1;

        ptLen = GCMDecryption(pt, ct, ctLen, macLen, nonce, nonceLen, aad, aadLen, mKey);
        if(ptLen == -1)
            return -1;

        return ptLen;
    }
}
