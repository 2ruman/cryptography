package kr.or.kisa.seed;

public class SEEDCCM {
    static {
        System.loadLibrary("seed");
    }

    private native int CCMEncryption(byte[] ct, byte[] pt, int ptLen, int macLen, byte[] nonce, int nonceLen, byte[] aad, int aadLen, byte[] key);
    private native int CCMDecryption(byte[] pt, byte[] ct, int ctLen, int macLen, byte[] nonce, int nonceLen, byte[] aad, int aadLen, byte[] key);

    public int CCM_Encryption(byte[] ct, byte[] pt, int ptLen, int macLen, byte[] nonce, int nonceLen, byte[] aad, int aadLen, byte[] mKey) {
        int ctLen;
        if(mKey == null)
            return -1;

        ctLen = CCMEncryption(ct, pt, ptLen, macLen, nonce, nonceLen, aad, aadLen, mKey);
        if(ctLen == -1)
            return -1;

        return ctLen;
    }

    public int CCM_Decryption(byte[] pt, byte[] ct, int ctLen, int macLen, byte[] nonce, int nonceLen, byte[] aad, int aadLen, byte[] mKey){
        int ptLen = 0;
        if(mKey == null)
            return -1;

        ptLen = CCMDecryption(pt, ct, ctLen, macLen, nonce, nonceLen, aad, aadLen, mKey);
        if(ptLen == -1)
            return -1;

        return ptLen;
    }
}
