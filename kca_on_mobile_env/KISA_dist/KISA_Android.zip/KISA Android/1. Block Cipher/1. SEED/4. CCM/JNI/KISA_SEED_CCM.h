#ifndef _SEED_CCM_H_
#define _SEED_CCM_H_


// include header
#include <jni.h>

// define


// function declare
#ifdef __cplusplus
extern "C" 
{
#endif
int SEED_CCM_Encryption(
    unsigned char *ct, unsigned int *ctLen,
    unsigned char *pt, unsigned int ptLen,
    unsigned int macLen,
    unsigned char *nonce, unsigned int nonceLen,
    unsigned char *aad, unsigned int aadLen,
    unsigned char *mKey);
int SEED_CCM_Decryption(
    unsigned char *pt, unsigned int *ptLen,
    unsigned char *ct, unsigned int ctLen,
    unsigned int macLen,
    unsigned char *nonce, unsigned int nonceLen,
    unsigned char *aad, unsigned int aadLen,
    unsigned char *mKey);

JNIEXPORT jint JNICALL
Java_kr_or_kisa_seed_SEEDCCM_CCMEncryption(JNIEnv* env, jobject thiz, jbyteArray Ct, jbyteArray Pt, jint PtLen, jint MacLen, jbyteArray Nonce, jint NonceLen, jbyteArray Aad, jint AadLen, jbyteArray Key);
JNIEXPORT jint JNICALL
Java_kr_or_kisa_seed_SEEDCCM_CCMDecryption(JNIEnv* env, jobject thiz, jbyteArray Pt, jbyteArray Ct, jint CtLen, jint MacLen, jbyteArray Nonce, jint NonceLen, jbyteArray Aad, jint AadLen, jbyteArray Key);
#ifdef __cplusplus
}
#endif



#else
#endif