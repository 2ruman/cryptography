package kr.or.kisa.seed;

public class SEEDCMAC {
    static {
        System.loadLibrary("seed");
    }

    private native int GenerateCMAC(byte[] mac, int macLen, byte[] in, int inLen, byte[] key);
    private native int VerifyCMAC(byte[] mac, int macLen, byte[] in, int inLen, byte[] key);

    public int Generate_CMAC(byte[] mac, int macLen, byte[] in, int inLen, byte[] key){
        if(key == null)
            return -1;
        if(GenerateCMAC(mac, macLen, in, inLen, key) == -1)
            return -1;

        return 0;
    }

    public int Verify_CMAC(byte[] mac, int macLen, byte[] in, int inLen, byte[] key){
        if(key == null)
            return -1;
        if(VerifyCMAC(mac, macLen, in, inLen, key) == -1)
            return -1;

        return 0;
    }
}
