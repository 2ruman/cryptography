#ifndef _SEED_CMAC_H_
#define _SEED_CMAC_H_

#include <jni.h>

#ifdef __cplusplus
extern "C"
{
#endif
void SEED_CMAC_SubkeySched(unsigned char *sKey);
int SEED_Generate_CMAC(unsigned char *pMAC, int macLen, unsigned char *pIn, int inLen, unsigned char *mKey);
int SEED_Verify_CMAC(unsigned char *pMAC, int macLen, unsigned char *pIn, int inLen, unsigned char *mKey);

JNIEXPORT jint JNICALL
Java_kr_or_kisa_seed_SEEDCMAC_GenerateCMAC(JNIEnv* env, jobject thiz, jbyteArray mac, jint macLen, jbyteArray in, jint inLen, jbyteArray key);
JNIEXPORT jint JNICALL
Java_kr_or_kisa_seed_SEEDCMAC_VerifyCMAC(JNIEnv* env, jobject thiz, jbyteArray mac, jint macLen, jbyteArray in, jint inLen, jbyteArray key);

#ifdef __cplusplus
}
#endif

#else
#endif