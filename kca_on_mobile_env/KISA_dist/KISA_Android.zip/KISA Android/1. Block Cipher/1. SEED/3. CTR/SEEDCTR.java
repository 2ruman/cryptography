package kr.or.kisa.seed;

public class SEEDCTR {
    public static final int SEED_BLOCK_SIZE = 16;

    public static final int ENC = 1;
    public static final int DEC = 0;

    private int 	encrypt;
    private byte[] 	ivec;
    private int[]	seedKey;
    private int[] 	buffer_length;
    private int[] 	last_block_flag;

    public SEEDCTR() {
        this.ivec = new byte[SEED_BLOCK_SIZE];
        this.seedKey = new int[32];
        this.buffer_length = new int[1];
        this.last_block_flag = new int[1];
    }
    static {
        System.loadLibrary("seed");
    }

    private native int CTREncrypt(byte[] key, byte[] ctr, byte[] input, int inputlen, byte[] output);
    private native int CTRDecrypt(byte[] key, byte[] ctr, byte[] input, int inputlen, byte[] output);
    private native int seedCTRInit(byte[] user_key, int[] seed_key);
    private native int seedCTRProcess(int[] seed_key, byte[] ivec, byte[] inputText, int inputTextLen, byte[] outputText, int[] buffer_length);
    private native int seedCTRClose(byte[] outputText, int outlen1, int[] buffer_length);

    public int init(int enc, byte[] key, byte[] ctr){
        if(key == null || ctr == null)
            return -1;
        if(seedCTRInit(key, this.seedKey) == -1)
            return -1;

        System.arraycopy(ctr, 0, this.ivec, 0, SEED_BLOCK_SIZE);
        this.encrypt = enc;
        this.last_block_flag[0] = this.buffer_length[0] = 0;

        return 0;
    }

    public int process(byte[] inputText, int inputTextLen, byte[] outputText){
        int outputTextLen = 0;

        if(inputText == null || outputText == null)
            return -1;

        if(inputTextLen <= 0)
            return -1;

        outputTextLen = seedCTRProcess(this.seedKey, this.ivec, inputText, inputTextLen, outputText, this.buffer_length);
        return outputTextLen;
    }

    public int close(byte[] outputText, int outlen1){
	int outputTextLen = 0;
        if(outputText == null)
            return -1;

        outputTextLen = seedCTRClose(outputText, outlen1, this.buffer_length);

        return outputTextLen;
    }

    public int CTR_ENCRYPT(byte[] key, byte[] ctr, byte[] inputText, int inputTextLen, byte[] outputText){
        int len;
        if(key == null || ctr == null || inputText == null || outputText == null)
            return -1;
        len = CTREncrypt(key, ctr, inputText, inputTextLen, outputText);

        if(len == 0)
            return -1;

        return len;
    }

    public int CTR_DECRYPT(byte[] key, byte[] ctr, byte[] inputText, int inputTextLen, byte[] outputText){
        int len;
        if(key == null || ctr == null || inputText == null || outputText == null)
            return -1;
        len = CTRDecrypt(key, ctr, inputText, inputTextLen, outputText);

        if(len == 0)
            return -1;

        return len;
    }
}
