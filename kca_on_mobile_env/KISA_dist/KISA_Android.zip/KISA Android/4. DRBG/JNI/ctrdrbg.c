#include <jni.h>

#include <string.h>
#include <stdio.h>
#include <stdlib.h>

#include "ctrdrbg.h"
#include "seedcbc.h"
#include "ariacbc.h"

# define octet_to_int(os) (((unsigned int)(os)[0] << 24) ^ ((unsigned int)(os)[1] << 16) ^ ((unsigned int)(os)[2] <<  8) ^ ((unsigned int)(os)[3]))
# define int_to_octet(os, i) { (os)[0] = (unsigned char)((i) >> 24); (os)[1] = (unsigned char)((i) >> 16); (os)[2] = (unsigned char)((i) >>  8); (os)[3] = (unsigned char)(i); }

static void ctr_increase(unsigned char *counter) {
	unsigned int c_byte;

	c_byte = octet_to_int(counter + 12);
	c_byte++;
	c_byte &= 0xFFFFFFFF;
	int_to_octet(counter + 12, c_byte);
	if (c_byte)
		return;

	c_byte = octet_to_int(counter +  8);
	c_byte++;
	c_byte &= 0xFFFFFFFF;
	int_to_octet(counter +  8, c_byte);

	if (c_byte)
		return;

	c_byte = octet_to_int(counter +  4);
	c_byte++;
	c_byte &= 0xFFFFFFFF;
	int_to_octet(counter +  4, c_byte);

	if (c_byte)
		return;


	c_byte = octet_to_int(counter +  0);
	c_byte++;
	c_byte &= 0xFFFFFFFF;
	int_to_octet(counter +  0, c_byte);
}

JNIEXPORT void JNICALL
Java_kr_or_kisa_seed_ctrdrbg_CTRDRBG_ctrIncrease(JNIEnv* env, jobject thiz, jbyteArray Counter) {
    unsigned char *counter = (unsigned char *)(*env)->GetPrimitiveArrayCritical(env, Counter, 0);

	ctr_increase(counter);

    (*env)->ReleasePrimitiveArrayCritical(env, Counter, counter, 0);
}

void KISA_BCC(char algo,
			  unsigned char* K,
			  unsigned char* data, int datalen,
			  unsigned char* output_block, int outlen)
{
	KISA_SEED_KEY seedkey;
	unsigned char *ariakey = NULL;
	int rounds = 0;
	int n = datalen/outlen;
	int i,j,idx;
	unsigned char inputblock[MAX_V_LEN_IN_BYTES];
	memset(inputblock,0x00,MAX_V_LEN_IN_BYTES);
	memset(output_block,0x00,outlen);

	ariakey = (unsigned char *)malloc(ARIA_MAXNR * (ARIA_MAXNR + 1));

	switch(algo) {
		case ALGO_SEED:
			KISA_SEED_init(K,&seedkey);

			for(j=1; j <= n; j++)
			{
				for(i=0; i<outlen; i++)
				{
					inputblock[i] = output_block[i] ^ data[i];
				}
				KISA_SEED_encrypt_block_(inputblock,output_block,&seedkey);
				data		 += SEED_BLOCK_SIZE;
			}
			break;
		case ALGO_ARIA128:
			KISA_ARIA_encrypt_init(K, 128, ariakey, &rounds);

			for(j=1; j <= n; j++)
			//for(j=1; j <= 2; j++)
			{
				for(i=0; i<outlen; i++)
				{
					inputblock[i] = output_block[i] ^ data[i];
				}
				KISA_ARIA_process_block(inputblock, output_block, ariakey, &rounds);
				data		 += ARIA_BLOCK_SIZE;
			}
			break;
		case ALGO_ARIA192:
			KISA_ARIA_encrypt_init(K, 192, ariakey, &rounds);

			for(j=1; j <= n; j++)
			{
				for(i=0; i<outlen; i++)
				{
					inputblock[i] = output_block[i] ^ data[i];
				}
				KISA_ARIA_process_block(inputblock, output_block, ariakey, &rounds);
				data		 += ARIA_BLOCK_SIZE;
			}
			break;
		case ALGO_ARIA256:
			KISA_ARIA_encrypt_init(K, 256, ariakey, &rounds);

			for(j=1; j <= n; j++)
			{
				for(i=0; i<outlen; i++)
				{
					inputblock[i] = output_block[i] ^ data[i];
				}
				KISA_ARIA_process_block(inputblock, output_block, ariakey, &rounds);
				data		 += ARIA_BLOCK_SIZE;
			}
			break;
	}

	memset(ariakey,0x00,ARIA_WORD_SIZE * (ARIA_MAXNR + 1));
	memset(&seedkey,0x00,sizeof(KISA_SEED_KEY));
	memset(inputblock,0x00,MAX_V_LEN_IN_BYTES);

	free(ariakey);
}

JNIEXPORT jint JNICALL
Java_kr_or_kisa_seed_ctrdrbg_CTRDRBG_blockCipherDf(JNIEnv* env, jobject thiz, jbyte algo, jbyteArray inputString, jint input_str_len,
		jbyteArray Output, jint outlen)
{
#define MAX_NUM_OF_BYTES_TO_RETURN 64
#define BLOCK_SIZE MAX_V_LEN_IN_BYTES
#define SIZE_INT	4
    jbyte *input_string = (*env)->GetByteArrayElements(env, inputString, 0);
	jbyte *output = (*env)->GetByteArrayElements(env, Output, 0);

	//unsigned char *input_string = (unsigned char *)(*env)->GetPrimitiveArrayCritical(env, inputString, 0);
    //unsigned char *output = (unsigned char *)(*env)->GetPrimitiveArrayCritical(env, Output, 0);

	int retcode = 0;
	int i = 0;
	int L = input_str_len;
	int N = outlen;
	unsigned char X [MAX_NUM_OF_BYTES_TO_RETURN];
	unsigned char K [ALGO_ARIA256_KEYLEN_IN_BYTES];	// Maximum length
	int KLen;
	unsigned char IV[BLOCK_SIZE];
	unsigned char block[BLOCK_SIZE];
	int j;
	unsigned char *S = NULL;
	int SLen = 0;
	unsigned char *temp = NULL;
	unsigned char *iv_s = NULL;
	int iv_s_len = 0;
	int templen = 0;
	unsigned char *ptr;
	KISA_SEED_KEY seedkey;
	unsigned char *ariakey = NULL;
	int rounds = 0;
	ariakey = (unsigned char *)malloc(ARIA_MAXNR * (ARIA_MAXNR + 1));

	if(outlen > MAX_NUM_OF_BYTES_TO_RETURN)
	{
		goto FREE_AND_EXIT;
	}

	// form S = L||N||input_string||0x80
	SLen = 8 + input_str_len + 1;
	if((SLen % SEED_BLOCK_SIZE) != 0)
		SLen += (SEED_BLOCK_SIZE - (SLen % SEED_BLOCK_SIZE));

	S = (unsigned char*)malloc(SLen);
	memset(S,0x00,SLen);
	int_to_octet(S    , L);
	int_to_octet(S + SIZE_INT, N);
	memcpy(S + SIZE_INT + SIZE_INT, input_string, input_str_len);
	S[SIZE_INT + SIZE_INT + input_str_len] = 0x80;

	for(j=0; j<ALGO_ARIA256_KEYLEN_IN_BYTES; j++)
			K[j] = j;

	KLen = (algo == ALGO_SEED) ? ALGO_SEED_KEYLEN_IN_BYTES : (algo == ALGO_ARIA128) ? ALGO_ARIA128_KEYLEN_IN_BYTES : (algo == ALGO_ARIA192) ? ALGO_ARIA192_KEYLEN_IN_BYTES : ALGO_ARIA256_KEYLEN_IN_BYTES;

	templen = (KLen+outlen) + (BLOCK_SIZE - ((KLen+outlen) % BLOCK_SIZE));
	temp = (unsigned char*)malloc(templen);
	ptr = temp;
	iv_s_len = SLen + BLOCK_SIZE;
	iv_s = (unsigned char*)malloc(iv_s_len);
	i = 0;
	templen = 0;
	while(templen < KLen + outlen){
		int_to_octet(IV,i);
		memset(IV+SIZE_INT,0x00,BLOCK_SIZE-SIZE_INT);
		memcpy(iv_s,IV,BLOCK_SIZE);
		memcpy(iv_s + BLOCK_SIZE,S,SLen);
		KISA_BCC(algo,K,iv_s,iv_s_len,block,BLOCK_SIZE);
		memcpy(ptr,block,BLOCK_SIZE);
		ptr += BLOCK_SIZE;
		templen += BLOCK_SIZE;
		i++;
	}

	memcpy(K,temp,KLen);
	memcpy(X,temp+KLen,outlen);

	memset(temp,0x00,templen);
	free(temp);

	temp = (unsigned char*)malloc((outlen) + (BLOCK_SIZE - ((outlen) % BLOCK_SIZE)));
	ptr = temp;
	templen = 0;
	//memset(temp, 0, (outlen)+(BLOCK_SIZE - ((outlen) % BLOCK_SIZE)));

	switch(algo)
	{
	case ALGO_SEED:
		KISA_SEED_init(K,&seedkey);
		while(templen < outlen){
			KISA_SEED_encrypt_block_(X,X,&seedkey);
			memcpy(ptr,X,BLOCK_SIZE);
			ptr += BLOCK_SIZE;
			templen += BLOCK_SIZE;
		}
		break;
	case ALGO_ARIA128:
		KISA_ARIA_encrypt_init(K, 128, ariakey, &rounds);
		while(templen < outlen){
			KISA_ARIA_process_block(X, X, ariakey, &rounds);
			memcpy(ptr,X,BLOCK_SIZE);
			ptr += BLOCK_SIZE;
			templen += BLOCK_SIZE;
		}
		break;
	case ALGO_ARIA192:
		KISA_ARIA_encrypt_init(K, 192, ariakey, &rounds);
		while(templen < outlen){
			KISA_ARIA_process_block(X, X, ariakey, &rounds);
			memcpy(ptr,X,BLOCK_SIZE);
			ptr += BLOCK_SIZE;
			templen += BLOCK_SIZE;
		}
		break;
	case ALGO_ARIA256:
		KISA_ARIA_encrypt_init(K, 256, ariakey, &rounds);
		while(templen < outlen){
			KISA_ARIA_process_block(X, X, ariakey, &rounds);
			memcpy(ptr,X,BLOCK_SIZE);
			ptr += BLOCK_SIZE;
			templen += BLOCK_SIZE;
		}
		break;
	}

	memcpy(output, temp, outlen);

	retcode = 1;
FREE_AND_EXIT:
	memset(ariakey, 0x00, ARIA_WORD_SIZE * (ARIA_MAXNR + 1));
	memset(&seedkey, 0x00, sizeof(KISA_SEED_KEY));
	if(S != NULL){
		memset(S,0x00,SLen);
		free(S);
	}
	if(temp != NULL){
		memset(temp,0x00,templen);
		free(temp);
	}
	if(iv_s != NULL){
		memset(iv_s,0x00,iv_s_len);
		free(iv_s);
	}
	memset(X,0x00,MAX_NUM_OF_BYTES_TO_RETURN);
	memset(K,0x00,ALGO_ARIA256_KEYLEN_IN_BYTES);
	memset(IV,0x00,BLOCK_SIZE);
	memset(block,0x00,BLOCK_SIZE);

	free(ariakey);

	(*env)->ReleaseByteArrayElements(env, inputString, input_string, 0);
	(*env)->ReleaseByteArrayElements(env, Output, output, 0);

	//(*env)->ReleasePrimitiveArrayCritical(env, inputString, input_string, 0);
	//(*env)->ReleasePrimitiveArrayCritical(env, Output, output, 0);

	return retcode;
}

JNIEXPORT jint JNICALL
Java_kr_or_kisa_seed_ctrdrbg_CTRDRBG_update(JNIEnv* env, jobject thiz, jbyteArray providedData, jint seedlen, jbyte algo, jbyteArray V_,
		jint Vlen, jbyteArray Key_, jint Keylen)
{
	unsigned char *provided_data = (unsigned char *)(*env)->GetPrimitiveArrayCritical(env, providedData, 0);
	unsigned char *V = (unsigned char *)(*env)->GetPrimitiveArrayCritical(env, V_, 0);
	unsigned char *Key = (unsigned char *)(*env)->GetPrimitiveArrayCritical(env, Key_, 0);

	unsigned char temp[MAX_SEEDLEN_IN_BYTES];
	int templen = 0;
	unsigned char *ptr;
	int i;
	int ptrindex = 0;
	KISA_SEED_KEY seedkey;
	unsigned char *ariakey = NULL;
	int rounds = 0;
	ariakey = (unsigned char *)malloc(ARIA_MAXNR * (ARIA_MAXNR + 1));

	if(provided_data == NULL || seedlen <= 0)
	{
		return 0;
	}

	ptr = temp;

	switch (algo){
		case ALGO_SEED:
			KISA_SEED_init(Key, &seedkey);
			while(templen < seedlen)
			{
				ctr_increase(V);
				KISA_SEED_encrypt_block_(V, ptr, &seedkey);
				ptr += SEED_BLOCK_SIZE;
				templen += SEED_BLOCK_SIZE;
			}
			memset(&seedkey, 0x00, sizeof(KISA_SEED_KEY));
			break;

		case ALGO_ARIA128:
			KISA_ARIA_encrypt_init(Key, 128, ariakey, &rounds);
			while(templen < seedlen)
			{
				ctr_increase(V);
				KISA_ARIA_process_block(V, ptr, ariakey, &rounds);
				ptr += ARIA_BLOCK_SIZE;
				templen += ARIA_BLOCK_SIZE;
			}
			memset(ariakey, 0x00, ARIA_WORD_SIZE * (ARIA_MAXNR + 1));
			break;

		case ALGO_ARIA192:
			KISA_ARIA_encrypt_init(Key, 192, ariakey, &rounds);
			while(templen < seedlen)
			{
				ctr_increase(V);
				KISA_ARIA_process_block(V, ptr, ariakey, &rounds);
				ptr += ARIA_BLOCK_SIZE;
				templen += ARIA_BLOCK_SIZE;
			}
			memset(ariakey, 0x00, ARIA_WORD_SIZE * (ARIA_MAXNR + 1));
			break;

		case ALGO_ARIA256:
			KISA_ARIA_encrypt_init(Key, 256, ariakey, &rounds);
			while(templen < seedlen)
			{
				ctr_increase(V);
				KISA_ARIA_process_block(V, ptr, ariakey, &rounds);
				ptr += ARIA_BLOCK_SIZE;
				templen += ARIA_BLOCK_SIZE;
			}
			memset(ariakey, 0x00, ARIA_WORD_SIZE * (ARIA_MAXNR + 1));
			break;
	}

	for(i = 0; i < seedlen; i++)
		temp[i] ^= provided_data[i];

	memcpy(Key, temp, Keylen);
	ptr = temp;
	memcpy(V, ptr + seedlen - (Vlen), Vlen);

	memset(temp, 0x00, seedlen);

	free(ariakey);

	(*env)->ReleasePrimitiveArrayCritical(env, providedData, provided_data, 0);
	(*env)->ReleasePrimitiveArrayCritical(env, V_, V, 0);
	(*env)->ReleasePrimitiveArrayCritical(env, Key_, Key, 0);

	return 1;
}